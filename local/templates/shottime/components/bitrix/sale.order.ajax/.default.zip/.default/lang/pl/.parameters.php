<?
$MESS["BACK_DEFAULT"] = "Wstecz";
$MESS["ECONOMY_DEFAULT"] = "Zapisz";
$MESS["EDIT_DEFAULT"] = "edytuj";
$MESS["FURTHER_DEFAULT"] = "Dalej";
$MESS["NAV_BACK_DEFAULT"] = "Wstecz";
$MESS["NAV_FORWARD_DEFAULT"] = "Dalej";
$MESS["SELECT_PICKUP_DEFAULT"] = "Wybierz";
?>