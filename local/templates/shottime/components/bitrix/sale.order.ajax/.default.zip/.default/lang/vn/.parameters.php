<?
$MESS["T_ALLOW_NEW_PROFILE"] = "Cho phép nhiều hồ sơ khách hàng";
$MESS["T_IMG_HEIGHT"] = "Chiều cao hình ảnh sản phẩm";
$MESS["T_IMG_WIDTH"] = "Chiều rộng hình ảnh sản phẩm";
$MESS["T_PAYMENT_SERVICES_NAMES"] = "Hiện tên hệ thống thanh toán";
$MESS["T_SHOW_STORES_IMAGES"] = "Hiện hình ảnh kho hàng trong biểu mẫu lựa chọn điểm đón khách";
?>