<?
$MESS["CAPTCHA_REGF_PROMT"] = "Nhập văn bản từ hình ảnh";
$MESS["CAPTCHA_REGF_TITLE"] = "Hãy nhập từ bạn thấy trong hình ảnh";
$MESS["SOA_NO_JS"] = "Quá trình đặt hàng yêu cầu JavaScript được kích hoạt trên hệ thống của bạn. JavaScript bị vô hiệu hóa hoặc không hỗ trợ bởi trình duyệt của bạn. Hãy thay đổi các thiết lập trình duyệt và <a href=\"\">thử lại</a>.";
$MESS["STOF_FORGET_PASSWORD"] = "Quên mật khẩu?";
$MESS["STOF_LASTNAME"] = "Họ";
$MESS["STOF_LOGIN"] = "Tên đăng nhập";
$MESS["STOF_MY_PASSWORD"] = "Tôi muốn đăng nhập và mật khẩu của riêng tôi";
$MESS["STOF_NAME"] = "Tên";
$MESS["STOF_NEXT_STEP"] = "Tiếp tục đặt hàng";
$MESS["STOF_PASSWORD"] = "Mật khẩu";
$MESS["STOF_RE_PASSWORD"] = "Lặp lại mật khẩu";
$MESS["STOF_SYS_PASSWORD"] = "Hệ thống tạo ra tên đăng nhập và mật khẩu";
?>